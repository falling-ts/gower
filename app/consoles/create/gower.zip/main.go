/*
Copyright (c) 2023 Falling TS

该源码使用 MIT 授权协议,
你可以在根目录下找到 MIT 授权协议.
*/

package main

import (
	"gitee.com/falling-ts/gower/app"
	_ "gitee.com/falling-ts/gower/bootstrap"
)

func main() {
	app.Run()
}
