package trans

import "github.com/falling-ts/gower/services"

var All = services.TransAll{
	"DBError": DBError,
}
