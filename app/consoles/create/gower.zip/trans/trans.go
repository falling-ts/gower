package trans

import "gower/services"

var All = services.TransAll{
	"DBError": DBError,
}
