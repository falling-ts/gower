package trans

import "gitee.com/falling-ts/gower/services"

var All = services.TransAll{
	"DBError": DBError,
}
