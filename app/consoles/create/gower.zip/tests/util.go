package tests

import (
	"fmt"
	"testing"
)

func TestUtil(*testing.T) {
	fmt.Println("----------------TestUtil 开始----------------")
	fmt.Println("----------------TestUtil 结束----------------")
}
