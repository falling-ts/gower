package tests

import (
	"fmt"
	"testing"
)

func TestUtil(t *testing.T) {
	fmt.Println("----------------TestUtil 开始----------------")
	fmt.Println("----------------TestUtil 结束----------------")
}
