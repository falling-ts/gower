package routes

import "gower/app"

var route = app.Route()
