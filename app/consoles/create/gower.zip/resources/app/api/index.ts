import auth from "./auth"
import v1 from "./v1"

export default {
    auth,
    v1
}
