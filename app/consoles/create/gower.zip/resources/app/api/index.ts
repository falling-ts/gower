import auth from "./auth"
import admin from "./admin"
import v1 from "./v1"


export default {
    auth,
    admin,
    v1
}
