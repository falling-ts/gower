export default {
    isPhone() {
        let screenWidth: number = window.innerWidth
        return screenWidth <= 768
    }
}
