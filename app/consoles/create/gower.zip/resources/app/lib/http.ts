export default {
    BadRequest: 400,
    Unauthorized: 401,
    UnprocessableEntity: 422
}
