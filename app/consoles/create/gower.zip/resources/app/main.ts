import "simplebar"
import $ from "jquery"
import api from "./api"
import msg from "./lib/msg"
import cookie from "js-cookie"
import crypto from "crypto-js"
import * as store from "localforage"
// @ts-ignore
import { createApp } from "vue/dist/vue.esm-browser.prod"
import ResizeObserver from "resize-observer-polyfill"

window.ResizeObserver = ResizeObserver

export {
    createApp,
    $,
    api,
    msg,
    cookie,
    store,
    crypto
}

// 样式
import "animate.css"
import "./styles/main.styl"
import "./styles/normalize.css"
import "tailwindcss/tailwind.css"
import "simplebar/dist/simplebar.css"

