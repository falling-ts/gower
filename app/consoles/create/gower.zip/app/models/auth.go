package models

type Auth struct {
	User
	AdminUser
}
