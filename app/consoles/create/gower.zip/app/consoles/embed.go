package consoles

import "embed"

//go:embed make/*
var tplFS embed.FS
