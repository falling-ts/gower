package app

type Controller struct{}

// Data HTML 数据
type Data map[string]any
