package middlewares

import (
	"gower/app/middlewares"
	"gower/services"
)

var _ = Auth()

func Auth() services.Handler {
	return middlewares.Auth("api-auth", "Authorization")
}
