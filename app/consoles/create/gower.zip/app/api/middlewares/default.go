package middlewares

import (
	"gower/app/middlewares"
	"gower/services"
)

var _ = Default()

func Default() services.Handler {
	return middlewares.Default("api-token")
}
