package controllers

import "gitee.com/falling-ts/gower/app"

var (
	res    = app.Response()
	upload = app.Upload()
	excp   = app.Exception()
)
