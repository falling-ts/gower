package middlewares

import (
	"gower/app/middlewares"
	"gower/app/models"
	"gower/services"
)

var _ = Auth()

func Auth() services.Handler {
	return middlewares.Auth("admin-token", "Admin-Authorization", func(id string) (*models.Auth, error) {
		adminUser := new(models.AdminUser)
		result := db.First(adminUser, id)
		if result.Error != nil {
			return nil, trans.DBError(result.Error)
		}

		return &models.Auth{AdminUser: *adminUser}, nil
	})
}
