package middlewares

import "gower/app"

var (
	db    = app.DB()
	trans = app.Translate()
)
