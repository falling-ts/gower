package public

import (
	"net/http"
)

var Static http.FileSystem
