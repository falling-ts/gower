//go:build !cli

package routes

import _ "gower/routes"
