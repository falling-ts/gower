package bootstrap

import _ "gower/app/consoles"
import _ "gower/bootstrap/routes"
import _ "gower/bootstrap/resources"
