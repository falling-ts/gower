package bootstrap

import (
	_ "github.com/falling-ts/gower/app/consoles"
	_ "github.com/falling-ts/gower/bootstrap/0/routes"
	_ "github.com/falling-ts/gower/bootstrap/1/resources"
)
