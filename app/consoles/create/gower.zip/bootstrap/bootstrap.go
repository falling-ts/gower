package bootstrap

import _ "gower/app/consoles"
import _ "gower/bootstrap/route"
import _ "gower/resources"
import _ "gower/routes"
