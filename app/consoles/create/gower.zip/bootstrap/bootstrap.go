package bootstrap

import (
	_ "gitee.com/falling-ts/gower/app/consoles"
	_ "gitee.com/falling-ts/gower/bootstrap/0/routes"
	_ "gitee.com/falling-ts/gower/bootstrap/1/resources"
)
