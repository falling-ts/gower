//go:build !cli

package routes

import _ "github.com/falling-ts/gower/routes"
