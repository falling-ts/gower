//go:build !cli

package routes

import _ "gitee.com/falling-ts/gower/routes"
