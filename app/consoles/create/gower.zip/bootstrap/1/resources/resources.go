//go:build !cli

package resources

import _ "gitee.com/falling-ts/gower/resources"
