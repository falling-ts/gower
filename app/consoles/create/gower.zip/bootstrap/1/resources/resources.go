//go:build !cli

package resources

import _ "github.com/falling-ts/gower/resources"
