//go:build !cli

package resources

import _ "gower/resources"
