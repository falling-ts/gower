import vite from "./vite.config"
import postcss from "./postcss.config"

console.log(vite)
console.log(postcss)
